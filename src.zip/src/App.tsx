import Header from './components/layout/Header';
import Main from './components/layout/Main';
import SideBar from './components/layout/SideBar';

function App() {
  return (
    <div className="font-mono">
      <Header />
      <div className="flex">
        <SideBar />
        <Main />
      </div>
    </div>
  );
}

export default App;
