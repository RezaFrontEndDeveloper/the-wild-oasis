import logo from '../../images/logo-light.png';

function Logo() {
  return <img src={logo} alt="" />;
}

export default Logo;
