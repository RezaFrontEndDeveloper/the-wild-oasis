import React from 'react';

function Main() {
  return <div className="h-screen w-full bg-blue-200">Main</div>;
}

export default Main;
