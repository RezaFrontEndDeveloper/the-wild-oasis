import React from 'react';

function SideBar() {
  return <div className="h-screen w-[250px] bg-red-400">SideBar</div>;
}

export default SideBar;
