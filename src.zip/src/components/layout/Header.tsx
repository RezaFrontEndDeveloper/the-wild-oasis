import { FaUser } from 'react-icons/fa';
import { FiLogOut } from 'react-icons/fi';

import Button from '../atoms/Button';
import Capstion from '../atoms/Capstion';
import DarkModeButton from '../molecules/DarkModeButton';

function Header() {
  return (
    <div className="flex items-center justify-end gap-8 bg-amber-200 p-10">
      <Capstion>X name</Capstion>
      <div className="flex items-center gap-2">
        <Button variant="logo">
          <FaUser className="cursor-pointer" />
        </Button>

        <DarkModeButton />

        <Button variant="logo">
          <FiLogOut className="cursor-pointer" />
        </Button>
      </div>
    </div>
  );
}

export default Header;
