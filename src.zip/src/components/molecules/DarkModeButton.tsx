import { IoMoon } from 'react-icons/io5';

function DarkModeButton() {
  return <IoMoon className="cursor-pointer" />;
}

export default DarkModeButton;
